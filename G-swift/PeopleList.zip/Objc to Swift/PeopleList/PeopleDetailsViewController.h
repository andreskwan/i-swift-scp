//
//  PeopleDetailsViewController.h
//  JSONRead

#import <UIKit/UIKit.h>

@interface PeopleDetailsViewController : UITableViewController

@property (strong, nonatomic) NSDictionary *details;

@end
