//
//  PeopleListViewController.h
//  JSONRead
//

#import <UIKit/UIKit.h>

@interface PeopleListViewController : UITableViewController

@end
