//
//  PlanetTableViewCell.swift
//  SpaceAdventure
//
//  Created by Andres Kwan on 11/6/15.
//  Copyright © 2015 Globant. All rights reserved.
//

import Foundation
import UIKit

class PlanetTableViewCell: UITableViewCell {
    @IBOutlet weak var labelPlanetName: UILabel!
    @IBOutlet weak var labelPlanetDescription: UILabel!
}